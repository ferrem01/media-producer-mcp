// Quotient Recorder -- popup: sign in + record/stop. The ONLY setup is
// "Sign in with Google": server/tenant/token are resolved by the account
// (background.js mirrors them into the settings the pipeline reads).
const $ = (id) => document.getElementById(id);

function renderAuth(st) {
  const signedIn = !!(st && st.signedIn);
  $("auth-out").style.display = signedIn ? "none" : "block";
  $("auth-in").style.display = signedIn ? "flex" : "none";
  $("record").dataset.needsAuth = signedIn ? "" : "1";
  $("record").disabled = !signedIn;
  $("capture").disabled = !signedIn;
  if (signedIn) {
    $("auth-name").textContent = st.name || "";
    $("auth-email").textContent = st.email || "";
    if (st.picture) { $("auth-pic").src = st.picture; $("auth-pic").style.display = "block"; }
    else $("auth-pic").style.display = "none";
  }
}

async function load() {
  try { $("ver").textContent = "v" + chrome.runtime.getManifest().version; } catch (e) {}
  const s = await chrome.storage.sync.get({ mic: true, camera: false, prompter: false, destProject: "" });
  $("mic").checked = !!s.mic;
  $("camera").checked = !!s.camera;
  $("prompter").checked = !!s.prompter;
  syncHints();
  const auth = await chrome.runtime.sendMessage({ type: "qr-auth-status" });
  renderAuth(auth);
  if (auth && auth.signedIn) loadDestinations(s.destProject);
  const { recording } = await chrome.runtime.sendMessage({ type: "qr-status" }) || {};
  setRecording(!!recording);
  const { qrLastStatus } = (await chrome.storage.session?.get("qrLastStatus")) || {};
  showStatus(qrLastStatus);
}

// "Save to" picker: default is a fresh assembled walkthrough; picking an
// existing project appends the take to it as a new scene instead.
async function loadDestinations(savedId) {
  const sel = $("dest");
  const res = await chrome.runtime.sendMessage({ type: "qr-projects" });
  if (!res || !res.ok) return; // keep the "New project" default silently
  // ALL non-failed projects, newest first -- you never know which one the
  // user wants to drop a take into (undated ones sink to the bottom).
  const projects = (res.projects || [])
    .filter((p) => p.status !== "failed")
    .sort((a, b) => (b.updated_at || "").localeCompare(a.updated_at || ""));
  for (const p of projects) {
    const opt = document.createElement("option");
    opt.value = p.project_id;
    opt.textContent = (p.name || p.project_id).slice(0, 48);
    sel.appendChild(opt);
  }
  // Restore the remembered destination -- but never point at a project that
  // no longer exists (the value silently stays "New project" then).
  if (savedId) sel.value = savedId;
  if (sel.value !== savedId) sel.value = "";
  const { destNeed } = await chrome.storage.sync.get({ destNeed: "" });
  loadNeeds(sel.value, destNeed);
}

// "For" picker: the screens the chosen project's storyboard still needs
// (SPEC-briefs.md, the sources). Picking one makes the recording fill that
// need -- it takes the slot the board held for it -- instead of appending
// a scene. Hidden when the project has no open screen need.
async function loadNeeds(projectId, savedNeed) {
  const wrap = $("need-wrap"), sel = $("need");
  while (sel.options.length > 1) sel.remove(1);
  if (!projectId) { wrap.style.display = "none"; chrome.storage.sync.set({ destNeed: "" }); return; }
  const res = await chrome.runtime.sendMessage({ type: "qr-needs", project: projectId });
  const needs = (res && res.ok && res.needs) || [];
  for (const n of needs) {
    const opt = document.createElement("option");
    opt.value = n.scene_index + ":" + n.asset_index;
    opt.textContent = `Scene ${n.scene_index + 1} · ${n.description}`.slice(0, 64);
    sel.appendChild(opt);
  }
  wrap.style.display = needs.length ? "" : "none";
  sel.value = savedNeed || "";
  if (sel.value !== (savedNeed || "")) sel.value = "";
  chrome.storage.sync.set({ destNeed: sel.value });
}

$("dest").addEventListener("change", () => {
  chrome.storage.sync.set({ destProject: $("dest").value, destNeed: "" });
  loadNeeds($("dest").value, "");
});
$("need").addEventListener("change", () => {
  chrome.storage.sync.set({ destNeed: $("need").value });
});

$("signin").addEventListener("click", async () => {
  $("signin").disabled = true;
  $("status").textContent = "Opening Google sign-in…";
  const res = await chrome.runtime.sendMessage({ type: "qr-signin" });
  $("signin").disabled = false;
  if (res && res.ok) {
    $("status").textContent = "";
    renderAuth({ signedIn: true, ...res });
    const { destProject } = await chrome.storage.sync.get({ destProject: "" });
    loadDestinations(destProject);
  } else {
    $("status").textContent = "Sign-in failed: " + ((res && res.error) || "unknown error");
  }
});

$("signout").addEventListener("click", async (e) => {
  e.preventDefault();
  await chrome.runtime.sendMessage({ type: "qr-signout" });
  renderAuth({ signedIn: false });
});

// Component camera: inject the picker into the page and get out of the way
// (the whole flow -- outline, capture, verdict, confirm -- lives in-page).
$("capture").addEventListener("click", async () => {
  const res = await chrome.runtime.sendMessage({ type: "qc-start" });
  if (res && res.ok) window.close();
  else $("status").textContent = (res && res.error) || "Could not start capture.";
});

function showStatus(st) {
  if (!st) return;
  // No re-record while a take is still uploading -- the offscreen recorder
  // is busy with the blob and a second session would collide with it.
  // (needsAuth: a terminal upload state must not re-enable a signed-out popup.)
  $("record").disabled = st.state === "uploading" || $("record").dataset.needsAuth === "1";
  if (st.state === "uploading") {
    const p = st.progress;
    $("status").textContent = p && p.total
      ? `Uploading… ${p.pct}% · ${(p.done / 1048576).toFixed(0)} / ${(p.total / 1048576).toFixed(0)} MB`
      : "Uploading…";
  }
  else if (st.state === "done") $("status").textContent = st.note || "Uploaded ✓ — assembling now; the film appears in Studio in a few minutes.";
  else if (st.state === "error") $("status").textContent = "Upload failed: " + (st.error || "unknown error");
  else if (st.state === "ready" && st.projectUrl) {
    $("status").innerHTML = "";
    const a = document.createElement("a");
    a.href = st.projectUrl;
    a.target = "_blank";
    a.textContent = "✓ Your walkthrough is ready — open in Studio";
    $("status").appendChild(a);
  }
}

// Live updates while the popup stays open: the offscreen uploader broadcasts
// progress, and the terminal state also lands in storage.session (covers a
// popup opened after the fact).
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === "qr-offscreen-status") showStatus({ state: msg.state, error: msg.error, progress: msg.progress, note: msg.note });
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "session" && changes.qrLastStatus?.newValue) showStatus(changes.qrLastStatus.newValue);
});

function setRecording(on) {
  const b = $("record");
  b.classList.toggle("recording", on);
  b.textContent = on ? "■ Stop recording" : "● Record this tab";
}

async function save() {
  await chrome.storage.sync.set({
    mic: $("mic").checked,
    camera: $("camera").checked,
    // A prompter with no voice to prompt is a window that does nothing.
    prompter: $("prompter").checked && $("mic").checked,
  });
}

async function ensurePermission(name, withCam) {
  // A permission prompt can't live in this popup (it steals focus, the
  // popup closes, the prompt cancels itself) -- the setup tab hosts it.
  let granted = false;
  try {
    const p = await navigator.permissions.query({ name });
    granted = p.state === "granted";
  } catch (e) { /* fall through to the setup tab */ }
  if (!granted) chrome.tabs.create({ url: chrome.runtime.getURL("mic.html") + (withCam ? "?cam=1" : "") });
  return granted;
}

// The mic check has to be reachable even once permission EXISTS. It used to
// open only when the grant was missing, which meant the people most likely to
// need it -- everyone already set up, recording every day -- could never get
// to it. A silent microphone is invisible until you watch the finished film.
// The teleprompter is only meaningful when there is a voice to prompt, and
// saying so beats silently doing nothing.
function syncHints() {
  const voice = $("mic").checked;
  const p = $("prompter");
  p.disabled = !voice;
  const hint = document.getElementById("prompter-hint");
  hint.textContent = voice
    ? "A separate window with your script, scrolling while you talk. Never appears on film."
    : "Turn on \u201cRecord my voice\u201d to use the teleprompter.";
  hint.style.opacity = voice ? "1" : "0.6";
  document.getElementById("cam-hint").textContent = voice
    ? "A picture-in-picture bubble of you over the demo."
    : "A picture-in-picture bubble of you over the demo \u2014 silent, since your voice is off.";
}
["mic", "camera", "prompter"].forEach((id) => {
  document.getElementById(id)?.addEventListener("change", () => {
    chrome.storage.sync.set({ [id]: document.getElementById(id).checked });
    syncHints();
  });
});

document.getElementById("mic-test")?.addEventListener("click", (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: chrome.runtime.getURL("mic.html") });
});

// Mode A needs mic permission for the extension origin, and a permission
// prompt can't live in this popup (the prompt steals focus, the popup
// closes, the prompt cancels itself). If not yet granted, open a dedicated
// setup tab that hosts the prompt; it flips the stored toggle on success.
$("mic").addEventListener("change", async (e) => {
  if (e.target.checked && !(await ensurePermission("microphone", false))) {
    e.target.checked = false; // mic.js sets it true once actually granted
    return;
  }
  save();
});

$("camera").addEventListener("change", async (e) => {
  if (e.target.checked && !(await ensurePermission("camera", true))) {
    e.target.checked = false; // mic.js sets it true once actually granted
    return;
  }
  save();
});

$("record").addEventListener("click", async () => {
  await save();
  const { recording } = await chrome.runtime.sendMessage({ type: "qr-status" }) || {};
  const res = await chrome.runtime.sendMessage({ type: recording ? "qr-stop" : "qr-start" });
  if (res && res.ok === false) { $("status").textContent = res.error; return; }
  setRecording(!recording);
  if (recording) {
    // Stopping -> upload begins; lock the button until a terminal status.
    $("record").disabled = true;
    $("status").textContent = "Stopped — uploading…";
  } else {
    $("status").textContent = "Recording… demo away.";
  }
});

load();
